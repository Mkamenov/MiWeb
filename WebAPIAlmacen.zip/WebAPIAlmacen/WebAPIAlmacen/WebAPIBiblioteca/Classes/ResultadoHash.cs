﻿namespace WebAPIBiblioteca.Classes
{
    public class ResultadoHash
    {
        public string Hash { get; set; }
        public byte[] Salt { get; set; }
    }
}
