﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Security.Cryptography;
using WebAPIBiblioteca.Classes;

namespace WebAPIBiblioteca.Services
{
    public class HashService
    {
        
        public ResultadoHash Hash(string textoPlano)
        {
            // Generamos el salt aleatorio
            var salt = new byte[16];
            using (var random = RandomNumberGenerator.Create())
            {
                random.GetBytes(salt); // Genera un array aleatorio de bytes
            }

            // Llamamos al método ResultadoHash y retornamos el hash con el salt
            return Hash(textoPlano, salt);
        }


        public ResultadoHash Hash(string textoPlano, byte[] salt)
        {
            //Pbkdf2 es un algoritmo de encriptación
            var claveDerivada = KeyDerivation.Pbkdf2(password: textoPlano,
                salt: salt, prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 100000,
                numBytesRequested: 32);

            var hash = Convert.ToBase64String(claveDerivada);

            return new ResultadoHash()
            {
                Hash = hash,
                Salt = salt
            };
        }
    }

}
