﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using WebAPIAlmacen.DTOs;
using WebAPIBiblioteca.DTOs;

namespace WebAPIBiblioteca.Filters
{
    public class FiltroDeExcepcion : ExceptionFilterAttribute
    {
        //Solo en este caso para ir creando un log de errores
        
        private readonly IWebHostEnvironment env;

        public FiltroDeExcepcion(IWebHostEnvironment env)
        {
            this.env = env;
            
        }

        //El metodo con exceptión recibe en un objeto de tipo exceptionContext la información de la excepción.
        public override void OnException(ExceptionContext context)
        {
           
            //Esto es si queremos crear un log de errores propio a un archivo
            var path = $@"{env.ContentRootPath}\wwwroot\logerrores.txt";
            using (StreamWriter writer = new StreamWriter(path, append: true))
            {
                writer.WriteLine(DateTime.Now+" - " + 
                    context.HttpContext.Connection.RemoteIpAddress +" - "+
                    context.HttpContext.Request.Path +" - " +
                    context.HttpContext.Request.Method +" - "+
                    context.Exception.Message);
            }
            
            //Importante. Devolvemos una respuesta uniforme en todos los errores no controlados
            //Construimos una respuesta
            var errorRespuesta = new DTOError()
            {
                Mensaje = context.Exception.Message,
                Error = context.Exception.ToString()
            };


            //La pasamos a un Json para que el Front la pueda manipular
            context.Result = new JsonResult(errorRespuesta);

            // Devuelve la excepción
            base.OnException(context);
        }
    }
}
