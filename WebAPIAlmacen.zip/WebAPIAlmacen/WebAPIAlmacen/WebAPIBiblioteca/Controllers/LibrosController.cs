﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIBiblioteca.DTOs;
using WebAPIBiblioteca.Models;
using WebAPIBiblioteca.Services;

namespace WebAPIBiblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibrosController : ControllerBase
    {
        private readonly MiBibliotecaContext context;
        private readonly OperacionesService operacionesService;
        private readonly GestorArchivosService gestorArchivosService;
        public LibrosController(MiBibliotecaContext context, OperacionesService operacionesService, GestorArchivosService gestorArchivosService)
        {
            this.context = context;
            this.operacionesService = operacionesService;
            this.gestorArchivosService = gestorArchivosService;
        }

        [HttpGet("/libros")]
        public async Task<ActionResult> GetLibrosTotal()
        {
            await operacionesService.AddOperacion("Consultar libros", "libros");
            var todosLibros = await context.Libros.ToListAsync();
            return Ok(todosLibros);
        }
        [HttpGet]
        public async Task<ActionResult> GetLibros()
        {
            var tieneAcceso = await operacionesService.PermisoAcceso();
            if (tieneAcceso == false)
            {
                return BadRequest("No han pasado 30 segundos desde tu última petición");
            }
            var libros = await context.Libros.ToListAsync();
            await operacionesService.AddOperacion("Consultar", "Libros");
            return Ok(libros);
        }



        [HttpGet("{isbn}")]
        public async Task<ActionResult> GetAutores(string isbn)
        {
            await operacionesService.AddOperacion("Consultar libros" + isbn, "libros");
            var libros = await context.Libros.Where(x => x.Isbn == isbn).ToListAsync();
            if (libros == null)
            {
                return NotFound($"No existen libros con el ISBN {isbn}");
            }
            else
            {
                return Ok(libros);
            }
        }

        [HttpGet("contiene/{texto}")]
        public async Task<ActionResult> GetLibrosConTexto(string texto)
        {

            var libros = await context.Libros.Where(x => x.Titulo == texto).ToListAsync();
            if (libros == null)
            {
                return NotFound($"No existen libros que contengan título el texto {texto}");
            }
            else
            {
                return Ok(libros);
            }
        }

        [HttpGet("ordenadosportitulo/{direccion}")]
        public async Task<ActionResult> GetLibrosOrdenados(bool direccion)
        {

           
            if (direccion)
            {
                return Ok(await context.Libros.OrderBy(x=>x.Titulo).ToListAsync());
            }
            else
            {
                return Ok(await context.Libros.OrderByDescending(x => x.Titulo).ToListAsync());
            }
        }

        [HttpGet("entredosprecios")]
        public async Task<ActionResult> GetLibrosEntreDosPreciosQueryString([FromQuery] decimal desde, [FromQuery] decimal hasta)
        {
            var libros =
                await context.Libros.Where(x => x.Precio >= desde && x.Precio <= hasta).ToListAsync();

            return Ok(libros);
        }

        [HttpGet("desdehasta/{desde}/{hasta}")]
        public async Task<ActionResult> GetProductosPaginacion(int desde, int hasta)
        {
            var libros = await context.Libros.Skip(desde).Take(hasta - desde).ToListAsync();
            return Ok(libros);
        }


        [HttpGet("venta")]
        public async Task<ActionResult> GetProductosSeleccionCamposDTO()
        {
            var libros = await
                context.Libros.OrderBy(x => x.Titulo)
                .Select(x => new DTOVentaLibro { TituloLibro = x.Titulo, PrecioLibro = x.Precio })
                .ToListAsync();

            return Ok(libros);
        }

        [HttpGet("librosagrupadospordescatalogado")]
        public async Task<ActionResult> GetLibrosAgrupadosPorDescatalogado()
        {
            var libros = await context.Libros.GroupBy(g => g.Descatalogados)
                .Select(x => new
                {
                    Descatalogado = x.Key,
                    Total = x.Count(),
                    Libros = x.ToList()
                }).ToListAsync();

            return Ok(libros);
        }

        [HttpGet("filtromultipleasqueryable")]
        public async Task<ActionResult> GetProductoFiltroMultipleAsQueryable([FromQuery] DTOLibrosFiltro filtro)
        {
            var consulta = context.Libros.AsQueryable();

            if (filtro.Precio!=0)
            {
                consulta = consulta.Where(x => x.Precio >filtro.Precio);
            }
           
            consulta = consulta.Where(x => x.Descatalogados == filtro.Descatalogado);
            var productos = await consulta.ToListAsync();
            return Ok(productos);
        }



        [HttpPost]
        public async Task<ActionResult> PostLibros(List<DTOLibro> libros)
        {
            foreach (var libro in libros)
            {
                var existeAutor = await context.Autores.AnyAsync(x => x.IdAutor == libro.AutorId);
                if (!existeAutor)
                {
                    return BadRequest("Autor inexistente");
                }

                var existeEditorial = await context.Editoriales.AnyAsync(x => x.IdEditorial == libro.EditorialId);
                if (!existeEditorial)
                {
                    return BadRequest("Editorial inexistente");
                }

                var newLibro = new Libro()
                {
                    Isbn = libro.Isbn,
                    Titulo = libro.Titulo,
                    Precio = libro.Precio,
                    Paginas = libro.Paginas,
                    Descatalogados = libro.Descatalogados,
                    AutorId = libro.AutorId,
                    EditorialId = libro.EditorialId,
                };

                await context.AddAsync(newLibro);
                await context.SaveChangesAsync();

            }

            return Created();
        }


        [HttpPost("imagen")]
        public async Task<ActionResult> PostLibros([FromForm] DTOAgregarLibroImagen libro)
        {
            Libro newLibro = new Libro
            {

                Isbn = libro.Isbn,
                Precio = libro.Precio,
                Titulo = libro.Titulo,
                Descatalogados=false,
                Paginas=libro.Paginas,
                AutorId=libro.AutorId,
                EditorialId=libro.EditorialId,
                FotoPortadaUrl=""
            };

            if (libro.FotoPortada != null)
            {
                using (var memoryStream = new MemoryStream())
                {
                    // Extraemos la imagen de la petición
                    await libro.FotoPortada.CopyToAsync(memoryStream);
                    // La convertimos a un array de bytes que es lo que necesita el método de guardar
                    var contenido = memoryStream.ToArray();
                    // Recibimos el nombre del archivo
                    // El servicio Transient GestorArchivosLocal instancia el servicio y cuando se deja de usar se destruye
                    newLibro.FotoPortadaUrl = await gestorArchivosService.GuardarArchivo(contenido, libro.FotoPortada.FileName, "imagenes");
                }
            }

            await context.AddAsync(newLibro);
            await context.SaveChangesAsync();
            return Ok(newLibro);
        }

        [HttpPut("imagen")]
        public async Task<ActionResult> PutProductos([FromForm] DTOAgregarLibroImagen libro)
        {
            var libroActualizar = await context.Libros.FindAsync(libro.Isbn);
            if (libroActualizar == null)
            {
                return NotFound();
            }

            libroActualizar.Titulo = libro.Titulo;
            libroActualizar.Precio = libro.Precio;
            libroActualizar.Paginas = libro.Paginas;
            libroActualizar.AutorId = libro.AutorId;
            libroActualizar.EditorialId = libro.EditorialId;

            if (libro.FotoPortada != null)
            {
                using (var memoryStream = new MemoryStream())
                {
                    await libro.FotoPortada.CopyToAsync(memoryStream);
                    var contenido = memoryStream.ToArray();
                    libroActualizar.FotoPortadaUrl = await gestorArchivosService.EditarArchivo(contenido, libro.FotoPortada.FileName, "imagenes", libroActualizar.FotoPortadaUrl);
                }
            }

            await context.SaveChangesAsync();
            return Ok(libroActualizar);
        }

        [HttpDelete("{id:int}")]
        public async Task<ActionResult> DeleteLibro(int id)
        {
            var libro = await context.Libros.FindAsync(id);

            if (libro is null)
            {
                return NotFound();
            }

            context.Remove(libro);
            await context.SaveChangesAsync();
            return Ok();
        }

        [HttpDelete("sql")]
        public async Task<ActionResult> DeleteLibroSQL(int id)
        {
            var libro = await context.Libros
                        .FromSqlInterpolated($"SELECT * FROM Libros WHERE AutorId = {id}")
                        .FirstOrDefaultAsync();

            if (libro != null)
            {
                return BadRequest("No se puede eliminar el autor porque tiene libros asociados");
            }
            await context.Database
                .ExecuteSqlInterpolatedAsync($@"DELETE FROM Autores WHERE IdAutor={id}");

            await context.SaveChangesAsync();
            return Ok();
        }
    }
}
