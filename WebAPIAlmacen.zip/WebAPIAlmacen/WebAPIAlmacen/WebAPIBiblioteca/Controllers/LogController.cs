﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPIBiblioteca.Models;
using WebAPIBiblioteca.Services;
using Microsoft.EntityFrameworkCore;

namespace WebAPIBiblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogController : ControllerBase
    {
        private readonly MiBibliotecaContext context;


        // Inyección de dependencia.
        // Como nuestro controller depende de MiAlmacenContext para poder desempeñar sus funciones, lo podemos inyectar en el constructor
        // La inyección de dependencia trae al constructor de la clase todas las dependencias que necesita y las pasa a variables privadas
        // de la clase

        public LogController(MiBibliotecaContext context)
        {
            this.context = context;

        }

        [HttpGet]
        public async Task<ActionResult> GetLogs()
        {
            var logs = await context.Logs.ToListAsync();
            return Ok(logs);
        }
    }
}
