﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPIBiblioteca.Models;
using WebAPIBiblioteca.Services;

namespace WebAPIBiblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OperacionesController : ControllerBase
    {
        private readonly MiBibliotecaContext context;
        
        
        public OperacionesController ( MiBibliotecaContext context)
        {
            this.context = context;
            
        }

        [HttpGet]
        public async Task<ActionResult> GetTodasOperaciones()
        {
            var todasOpraciones = await context.Operaciones.ToListAsync();
            return Ok(todasOpraciones);
        }
    }
}
