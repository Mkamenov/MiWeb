﻿namespace WebAPIBiblioteca.DTOs
{
    public class DTOLibrosFiltro
    {
        public decimal Precio { get; set; }
        public bool Descatalogado { get; set; }
    }
}
