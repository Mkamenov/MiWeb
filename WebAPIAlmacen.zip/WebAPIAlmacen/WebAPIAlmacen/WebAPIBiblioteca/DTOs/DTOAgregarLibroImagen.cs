﻿namespace WebAPIBiblioteca.DTOs
{
    public class DTOAgregarLibroImagen
    {
        public string Titulo { get; set; }
        public string Isbn { get; set; }
        public decimal Precio { get; set; }
        public int Paginas { get; set; }
        public int AutorId { get; set; }
        public int EditorialId { get; set; }
        public IFormFile FotoPortada { get; set; }
    }
}
