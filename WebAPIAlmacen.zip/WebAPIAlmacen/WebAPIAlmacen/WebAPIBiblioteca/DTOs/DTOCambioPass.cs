﻿namespace WebAPIBiblioteca.DTOs
{
    public class DTOCambioPass
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string NewPass { get; set; }
    }
}
