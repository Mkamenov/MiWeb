﻿namespace WebAPIBiblioteca.DTOs
{
    public class DTOVentaLibro
    {
        public string TituloLibro { get; set; }
        public decimal PrecioLibro { get; set; }
    }
}
