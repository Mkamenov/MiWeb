﻿namespace WebAPIBiblioteca.DTOs
{
    public class DTOAutor
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

    }
}
