﻿namespace WebAPIAlmacen.DTOs
{
    public class DTOError
    {
        public string Mensaje { get; set; }
        public string Error { get; set; }

    }
}
